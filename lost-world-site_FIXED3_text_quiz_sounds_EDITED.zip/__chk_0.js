
document.addEventListener('DOMContentLoaded', () => {
  // --- Modal elements ---
  const modal = document.getElementById('vmodal');
  const shotA = document.getElementById('vshotA');
  const shotB = document.getElementById('vshotB');
  const nameEl = document.getElementById('vname');
  const descEl = document.getElementById('vdesc');
  const closeBtn = document.getElementById('vclose');
  const soundBtn = document.getElementById('soundToggle');
  const backdrop = modal ? modal.querySelector('.backdrop') : null;

  if(!modal){ console.error('vmodal missing'); return; }

  // --- State ---
  let currentScene = 'default';
  let soundEnabled = (localStorage.getItem('lw_sound') === 'on');

  function updateSoundUI(){
    if(!soundBtn) return;
    soundBtn.classList.toggle('on', soundEnabled);
    soundBtn.setAttribute('aria-label', soundEnabled ? 'Звук: включен' : 'Звук: выключен');
    soundBtn.title = soundEnabled ? 'Выключить звук' : 'Включить звук';
  }
  updateSoundUI();

  // --- WebAudio (Safari gated) ---
  let ctx = null;
  let audioState = null; // {gain, timers..., padOsc, padTimer}
  function getCtx(){
    if(!ctx){ ctx = new (window.AudioContext || window.webkitAudioContext)(); }
    if(ctx.state === 'suspended'){ ctx.resume(); }
    return ctx;
  }
  function pan(node){
    const c = getCtx();
    if(c.createStereoPanner){
      const p = c.createStereoPanner();
      p.pan.setValueAtTime((Math.random()*0.8)-0.4, c.currentTime);
      node.connect(p);
      return p;
    }
    return node;
  }
  function stopSound(){
    try{
      if(!audioState) return;
      const c = getCtx();
      const clear = (k)=>{ if(audioState[k]){ clearInterval(audioState[k]); audioState[k]=null; } };
      ['tBird','tFrog','tCicada','tMonkey','tTribal','tRoar','tPaper','tPencil','tWhip','tThunder','padTimer'].forEach(clear);
      if(audioState.padOsc){
        try{ audioState.padOsc.stop(); }catch(e){}
        audioState.padOsc = null;
      }
      if(audioState.gain){
        audioState.gain.gain.setTargetAtTime(0.0001, c.currentTime, 0.12);
      }
    }catch(e){}
    audioState = null;
  }

  // --- Melody: NEW original (mysterious, adventure-ish; not a copy) ---
  function startMelody(master){
    // Natural-ish wooden plucks: noise burst through resonant bandpass (less "electronic")
    const c = getCtx();
    const scale = [261.63, 293.66, 311.13, 392.00, 440.00]; // C D Eb G A
    let step = 0;

    function noiseBuffer(dur=0.45, amp=0.6){
      const sr = c.sampleRate;
      const len = Math.floor(sr*dur);
      const buf = c.createBuffer(1, len, sr);
      const d = buf.getChannelData(0);
      for(let i=0;i<len;i++){
        // slightly "brown" noise for warmth
        const x = (Math.random()*2-1);
        d[i] = x * amp * (1 - i/len);
      }
      return buf;
    }

    function woodenPluck(freq){
      const t = c.currentTime;
      const src = c.createBufferSource();
      src.buffer = noiseBuffer(0.35, 0.35);

      const bp = c.createBiquadFilter();
      bp.type='bandpass';
      bp.frequency.setValueAtTime(freq, t);
      bp.Q.value = 14; // resonance (wood)

      const lp = c.createBiquadFilter();
      lp.type='lowpass';
      lp.frequency.setValueAtTime(3800, t);

      const g = c.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.linearRampToValueAtTime(0.04, t + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.40);

      // gentle stereo delay
      const delay = c.createDelay(1.0);
      delay.delayTime.value = 0.30;
      const fb = c.createGain(); fb.gain.value = 0.16;
      const wet = c.createGain(); wet.gain.value = 0.09;

      src.connect(bp); bp.connect(lp); lp.connect(g);
      g.connect(master);           // dry
      g.connect(delay);
      delay.connect(wet); wet.connect(master);
      delay.connect(fb); fb.connect(delay);

      src.start(t);
      src.stop(t + 0.36);
    }

    const timer = setInterval(() => {
      if(!audioState || !soundEnabled) return;
      const idx = (step + (Math.random() < 0.35 ? 2 : 0)) % scale.length;
      const freq = scale[idx] * (Math.random() < 0.18 ? 0.5 : 1);
      woodenPluck(freq);
      step = (step + 1) % scale.length;
    }, 1200);

    setTimeout(() => { if(audioState && soundEnabled) woodenPluck(scale[0]); }, 150);
    return {osc:null, timer};
  }

  // --- Jungle residents ---
  function bird(master){
    const c = getCtx();
    const t = c.currentTime;

    // Noise chirp for "air" + very soft sine hint
    const dur = 0.16;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      d[i] = (Math.random()*2-1) * 0.35;
    }
    const n = c.createBufferSource();
    n.buffer = buf;

    const bp = c.createBiquadFilter();
    bp.type='bandpass';
    const f0 = 2000 + Math.random()*1800;
    bp.frequency.setValueAtTime(f0, t);
    bp.frequency.exponentialRampToValueAtTime(f0*(0.7+Math.random()*0.15), t+dur);
    bp.Q.value = 8;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.020, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    // Soft tonal hint
    const o = c.createOscillator();
    o.type='sine';
    o.frequency.setValueAtTime(1200 + Math.random()*900, t);
    const og = c.createGain();
    og.gain.setValueAtTime(0.0001, t);
    og.gain.linearRampToValueAtTime(0.006, t+0.01);
    og.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    n.connect(bp); bp.connect(g);
    o.connect(og);

    pan(g).connect(master);
    pan(og).connect(master);

    n.start(t); n.stop(t+dur+0.01);
    o.start(t); o.stop(t+dur+0.01);
  }

  function frog(master){
    const c = getCtx();
    const t = c.currentTime;

    // Breathy croak: noise through two formants + slight pitch drop sine
    const dur = 0.28;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      // darker noise
      d[i] = (Math.random()*2-1) * 0.45;
    }
    const n = c.createBufferSource();
    n.buffer = buf;

    const f1 = c.createBiquadFilter();
    f1.type='bandpass'; f1.frequency.value = 420; f1.Q.value = 6;
    const f2 = c.createBiquadFilter();
    f2.type='bandpass'; f2.frequency.value = 720; f2.Q.value = 4;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.045, t+0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    // pitch hint
    const o = c.createOscillator();
    o.type='sine';
    const p0 = 260 + Math.random()*70;
    o.frequency.setValueAtTime(p0, t);
    o.frequency.exponentialRampToValueAtTime(p0*0.62, t+dur);
    const og = c.createGain();
    og.gain.setValueAtTime(0.0001, t);
    og.gain.linearRampToValueAtTime(0.010, t+0.03);
    og.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    n.connect(f1); f1.connect(f2); f2.connect(g);
    o.connect(og);

    pan(g).connect(master);
    pan(og).connect(master);

    n.start(t); n.stop(t+dur+0.01);
    o.start(t); o.stop(t+dur+0.01);
  }

  function cicada(master){
    const c = getCtx();
    const t = c.currentTime;

    // Cicada: rapid gated noise (more natural than square wave)
    const dur = 0.18;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    const rate = 28 + Math.random()*10; // pulses
    for(let i=0;i<len;i++){
      const tt = i/sr;
      const gate = (Math.sin(2*Math.PI*rate*tt) > 0.6) ? 1 : 0;
      d[i] = (Math.random()*2-1) * 0.35 * gate;
    }
    const n = c.createBufferSource();
    n.buffer = buf;

    const bp = c.createBiquadFilter();
    bp.type='bandpass';
    bp.frequency.value = 5200 + Math.random()*500;
    bp.Q.value = 1.4;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.022, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    n.connect(bp); bp.connect(g);
    pan(g).connect(master);

    n.start(t); n.stop(t+dur+0.01);
  }

  function monkeyCall(master, strength=1.0){
    const c = getCtx();
    const t = c.currentTime;

    // More natural "whoop": sine + breath noise + formant
    const o = c.createOscillator();
    o.type='sine';
    const f1 = 520 + Math.random()*120;
    const f2 = 860 + Math.random()*140;
    o.frequency.setValueAtTime(f1, t);
    o.frequency.setValueAtTime(f2, t+0.12);
    o.frequency.setValueAtTime(f1*0.9, t+0.26);

    const form = c.createBiquadFilter();
    form.type='bandpass';
    form.frequency.value = 900;
    form.Q.value = 1.2;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.12*strength, t+0.03);
    g.gain.exponentialRampToValueAtTime(0.0001, t+0.55);

    // breath noise layer
    const dur = 0.45;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      d[i] = (Math.random()*2-1) * 0.18;
    }
    const n = c.createBufferSource();
    n.buffer = buf;

    const hp = c.createBiquadFilter();
    hp.type='highpass'; hp.frequency.value = 600;

    const ng = c.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.linearRampToValueAtTime(0.05*strength, t+0.03);
    ng.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    o.connect(form); form.connect(g);
    n.connect(hp); hp.connect(ng);

    pan(g).connect(master);
    pan(ng).connect(master);

    o.start(t); o.stop(t+0.60);
    n.start(t); n.stop(t+dur+0.01);

    // occasional chatter (short noise clicks)
    if(Math.random() < 0.6){
      const cdur = 0.18;
      const clen = Math.floor(sr*cdur);
      const cbuf = c.createBuffer(1, clen, sr);
      const cd = cbuf.getChannelData(0);
      const rate = 45 + Math.random()*20;
      for(let i=0;i<clen;i++){
        const tt = i/sr;
        const gate = (Math.sin(2*Math.PI*rate*tt) > 0.85) ? 1 : 0;
        cd[i] = (Math.random()*2-1) * 0.25 * gate;
      }
      const cn = c.createBufferSource(); cn.buffer = cbuf;
      const cbp = c.createBiquadFilter(); cbp.type='bandpass'; cbp.frequency.value = 1800; cbp.Q.value=1.6;
      const cg = c.createGain();
      cg.gain.setValueAtTime(0.0001, t+0.10);
      cg.gain.linearRampToValueAtTime(0.03*strength, t+0.12);
      cg.gain.exponentialRampToValueAtTime(0.0001, t+0.28);
      cn.connect(cbp); cbp.connect(cg);
      pan(cg).connect(master);
      cn.start(t+0.10); cn.stop(t+0.28);
    }
  }

  function tribalCall(master){
    const c = getCtx();
    const t = c.currentTime;

    // Vocal-like call: triangle + breath noise + longer echo
    const o = c.createOscillator();
    o.type='triangle';
    o.frequency.setValueAtTime(360, t);
    o.frequency.exponentialRampToValueAtTime(740, t+0.40);
    o.frequency.exponentialRampToValueAtTime(320, t+1.10);

    const form = c.createBiquadFilter();
    form.type='bandpass';
    form.frequency.value = 700;
    form.Q.value = 0.9;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.18, t+0.07);
    g.gain.exponentialRampToValueAtTime(0.0001, t+1.35);

    // breath
    const dur = 1.10;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      d[i] = (Math.random()*2-1) * 0.16;
    }
    const n = c.createBufferSource(); n.buffer = buf;
    const nbp = c.createBiquadFilter(); nbp.type='bandpass'; nbp.frequency.value = 1200; nbp.Q.value = 0.8;
    const ng = c.createGain();
    ng.gain.setValueAtTime(0.0001, t);
    ng.gain.linearRampToValueAtTime(0.06, t+0.06);
    ng.gain.exponentialRampToValueAtTime(0.0001, t+dur);

    // echo
    const delay = c.createDelay(1.0);
    delay.delayTime.value = 0.34;
    const fb = c.createGain(); fb.gain.value = 0.25;
    const wet = c.createGain(); wet.gain.value = 0.16;

    o.connect(form); form.connect(g);
    n.connect(nbp); nbp.connect(ng);

    // dry
    g.connect(master);
    ng.connect(master);

    // wet
    g.connect(delay);
    delay.connect(wet); wet.connect(master);
    delay.connect(fb); fb.connect(delay);

    o.start(t); o.stop(t+1.45);
    n.start(t); n.stop(t+dur+0.01);
  }

  
  function paper(master){
    const c = getCtx();
    const t = c.currentTime;
    const dur = 0.22;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      d[i] = (Math.random()*2-1) * 0.22 * (1 - i/len);
    }
    const n = c.createBufferSource(); n.buffer = buf;
    const hp = c.createBiquadFilter(); hp.type='highpass'; hp.frequency.value = 1200;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.06, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    n.connect(hp); hp.connect(g);
    pan(g).connect(master);
    n.start(t); n.stop(t+dur+0.01);
  }
  function pencil(master){
    const c = getCtx();
    const t = c.currentTime;
    const dur = 0.18;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      const tt = i/sr;
      const gate = (Math.sin(2*Math.PI*(38+Math.random()*8)*tt) > 0.8) ? 1 : 0;
      d[i] = (Math.random()*2-1) * 0.18 * gate;
    }
    const n = c.createBufferSource(); n.buffer = buf;
    const bp = c.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value = 1600; bp.Q.value=1.6;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.05, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    n.connect(bp); bp.connect(g);
    pan(g).connect(master);
    n.start(t); n.stop(t+dur+0.01);
  }
  function whip(master){
    const c = getCtx();
    const t = c.currentTime;
    const dur = 0.10;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      d[i] = (Math.random()*2-1) * 0.55 * (1 - i/len);
    }
    const n = c.createBufferSource(); n.buffer = buf;
    const bp = c.createBiquadFilter(); bp.type='bandpass'; bp.frequency.value = 2400; bp.Q.value=0.9;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.09, t+0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    n.connect(bp); bp.connect(g);
    pan(g).connect(master);
    n.start(t); n.stop(t+dur+0.01);
  }
  function thunder(master){
    const c = getCtx();
    const t = c.currentTime;
    const dur = 0.9;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      const x = (Math.random()*2-1);
      d[i] = x * 0.35 * (1 - i/len);
    }
    const n = c.createBufferSource(); n.buffer = buf;
    const lp = c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value = 220;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.12, t+0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    n.connect(lp); lp.connect(g);
    pan(g).connect(master);
    n.start(t); n.stop(t+dur+0.01);
  }

function roar(master){
    // Deeper + longer roar with noise "throat" layer (more natural)
    const c = getCtx();
    const t = c.currentTime;

    const o = c.createOscillator();
    o.type='sawtooth';
    o.frequency.setValueAtTime(62, t);
    o.frequency.exponentialRampToValueAtTime(26, t + 2.8);

    const sub = c.createOscillator();
    sub.type='sine';
    sub.frequency.setValueAtTime(34, t);
    sub.frequency.exponentialRampToValueAtTime(18, t + 2.8);

    // Throat noise
    const dur = 2.4;
    const sr = c.sampleRate;
    const len = Math.floor(sr*dur);
    const buf = c.createBuffer(1, len, sr);
    const d = buf.getChannelData(0);
    for(let i=0;i<len;i++){
      // darker noise with slow decay
      d[i] = (Math.random()*2-1) * 0.25 * (1 - i/len);
    }
    const n = c.createBufferSource(); n.buffer = buf;

    const shaper = c.createWaveShaper();
    const k = 22, nn = 44100;
    const curve = new Float32Array(nn);
    for(let i=0;i<nn;i++){
      const x = (i*2/nn)-1;
      curve[i] = (1+k)*x/(1+k*Math.abs(x));
    }
    shaper.curve = curve; shaper.oversample = '2x';

    const lp = c.createBiquadFilter();
    lp.type='lowpass';
    lp.frequency.setValueAtTime(520, t);
    lp.frequency.exponentialRampToValueAtTime(110, t + 2.8);

    const bp = c.createBiquadFilter();
    bp.type='bandpass';
    bp.frequency.setValueAtTime(240, t);
    bp.frequency.exponentialRampToValueAtTime(180, t+dur);
    bp.Q.value = 0.7;

    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.34, t + 0.25);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 3.2);

    o.connect(shaper); sub.connect(shaper);
    n.connect(bp);

    shaper.connect(lp);
    bp.connect(lp);
    lp.connect(g);
    g.connect(master);

    // slight echo tail
    const delay = c.createDelay(1.0);
    delay.delayTime.value = 0.28;
    const fb = c.createGain(); fb.gain.value = 0.18;
    const wet = c.createGain(); wet.gain.value = 0.14;
    g.connect(delay);
    delay.connect(wet); wet.connect(master);
    delay.connect(fb); fb.connect(delay);

    o.start(t); sub.start(t);
    n.start(t);
    o.stop(t + 3.3); sub.stop(t + 3.3);
    n.stop(t + dur + 0.01);
  }

  function startSound(scene){
    if(!soundEnabled) return;
    const c = getCtx();
    stopSound();

    const now = c.currentTime;
    const master = c.createGain();
    master.gain.setValueAtTime(0.0001, now);
    master.gain.linearRampToValueAtTime(0.18, now + 0.20);
    master.connect(c.destination);

    audioState = {gain: master, tBird:null, tFrog:null, tCicada:null, tMonkey:null, tTribal:null, tRoar:null, tPaper:null, tPencil:null, tWhip:null, tThunder:null, padTimer:null, padOsc:null};

    const mel = startMelody(master);
    audioState.padOsc = mel.osc;
    audioState.padTimer = mel.timer;

    // base ambience (birds not too often)
    audioState.tCicada = setInterval(()=>{ if(audioState && soundEnabled) cicada(master); }, 420 + Math.random()*260);
    audioState.tFrog   = setInterval(()=>{ if(audioState && soundEnabled) frog(master);   }, 1600 + Math.random()*1000);
    audioState.tBird   = setInterval(()=>{ if(audioState && soundEnabled) bird(master);   }, 2000 + Math.random()*1600);

    // scene specific
    if(scene === 'malone'){ audioState.tPaper=setInterval(()=>{ if(audioState && soundEnabled) paper(master); }, 3200+Math.random()*1800); paper(master); }
    if(scene === 'summerlee'){ audioState.tPencil=setInterval(()=>{ if(audioState && soundEnabled) pencil(master); }, 2600+Math.random()*1600); pencil(master); }
    if(scene === 'roxton'){ audioState.tWhip=setInterval(()=>{ if(audioState && soundEnabled) whip(master); }, 4200+Math.random()*2200); whip(master); }
    if(scene === 'challenger'){ audioState.tThunder=setInterval(()=>{ if(audioState && soundEnabled) thunder(master); }, 5200+Math.random()*2600); thunder(master); }
    if(scene === 'apeman'){
      audioState.tMonkey = setInterval(()=>{ if(audioState && soundEnabled) monkeyCall(master, 1.25); }, 900 + Math.random()*600);
      monkeyCall(master, 1.25);
    }
    if(scene === 'chiefson'){
      audioState.tTribal = setInterval(()=>{ if(audioState && soundEnabled) tribalCall(master); }, 3400 + Math.random()*2200);
      tribalCall(master);
    }
    if(scene === 'raptor'){
      audioState.tRoar = setInterval(()=>{ if(audioState && soundEnabled) roar(master); }, 7000 + Math.random()*5000);
      roar(master);
    }
  }

  if(soundBtn){
    soundBtn.addEventListener('click', ()=>{
      soundEnabled = !soundEnabled;
      localStorage.setItem('lw_sound', soundEnabled ? 'on' : 'off');
      updateSoundUI();
      if(soundEnabled){
        if(modal.classList.contains('open')) startSound(currentScene);
        else startSound('default');
      } else {
        stopSound();
      }
    });
  }

  // --- Open/Close ---
  function openModal(card){
    const img = card.getAttribute('data-img');
    const name = card.getAttribute('data-name');
    const desc = card.getAttribute('data-desc');
    currentScene = (card.getAttribute('data-scene')||'').replace('scene-','') || 'default';

    if(shotA) shotA.style.backgroundImage = "url('" + img + "')";
    if(shotB) shotB.style.backgroundImage = "url('" + img + "')";
    if(nameEl) nameEl.textContent = name || '';
    if(descEl) descEl.textContent = desc || '';

    modal.classList.add('open');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';

    if(soundEnabled) startSound(currentScene);
  }

  function closeModal(){
    modal.classList.remove('open');
    modal.style.display = 'none';
    document.body.style.overflow = '';
    stopSound();
  }

  document.querySelectorAll('.video-card').forEach(card => {
    card.addEventListener('click', () => openModal(card));
    card.addEventListener('keydown', (e)=>{
      if(e.key==='Enter' || e.key===' '){ e.preventDefault(); openModal(card); }
    });
  });

  if(closeBtn) closeBtn.addEventListener('click', closeModal);
  if(backdrop) backdrop.addEventListener('click', closeModal);

  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape' && modal.classList.contains('open')) closeModal();
  });
});
